use superstore_us;

create table orders(
		row_id int primary key not null,
        order_priority char(20),
        discount decimal(7,2),
        unit_price decimal(7,2),
        shipping_cost decimal(7,2),
        customer_id int not null,
        customer_name char(30),
        ship_mode char(30),
        customer_segment char(30),
        product_category char(30),
        product_sub_category varchar(70),
        product_base_margin decimal(7,2),
        country char(30),
        region char(15),
        state_province char(30),
        city char(30),
        order_date date,
        ship_date date,
        profit decimal(7,2),
        quantity_ordered_new int,
        order_id int not null,
        sales decimal(7,2)
	);
    
    
    alter table orders add 
    foreign key(order_id) references o_return(order_id);
    
    alter table orders add 
    foreign key(region) references users(region);
    
    
create table o_return( 
	order_id int primary key, 
    Order_status char(20)
);
       
create table users( 
	region char(15) unique,
    manager char(30)
);
 
 select * from orders;
 
-- to check what is the most used shipmode and how many times it has been used 
 select ship_mode, count(ship_mode) from orders group by ship_mode; 
 
 -- to check the most used customer segment orders comming from
 select customer_segment, count(customer_segment) from orders group by customer_segment order by count(customer_segment) asc;
 
 -- most to least sold product/sub product category order by region
 select product_category as product, count(product_category) as total_sold, product_sub_category as sub_category, region 
 from orders 
 group by product, region, sub_category  
 order by product, region desc; 
 
 -- Q. top to bottom most sales done region wise less return orders 
 -- Step1: first we check the duplicate entries in both the tables(order_return and orders made)
 select orders.order_id, o_return.order_id as r_orders, count(*) as duplicate_count
 from orders
 join o_return on orders.order_id = o_return.order_id
 group by orders.order_id, o_return.order_id;

 -- Step 2: then we check the number of duplicate entries
 select sum(duplicate_count) from (select orders.order_id, o_return.order_id as r_orders, count(*) as duplicate_count
 from orders
 join o_return on orders.order_id = o_return.order_id
 group by orders.order_id, o_return.order_id ) as derived_table;
 
 -- Step 3: we get the answer to the question asked 
-- select orders.order_id -(select orders.order_id from orders 
-- join o_return on orders.order_id = o_return.order_id) from orders as net_orders
select orders.order_id from orders where order_id not in( select o_return.order_id from o_return);

-- STEP 4: we check if the data give is correct or not by counting the total orders(1935) and substracting the common order_return value (15) to get result as 1920 
-- CHECK_STEP 1

select count(orders.order_id) from orders;
-- CHECK STEP 2

 select sum(duplicate_count) from (select orders.order_id, o_return.order_id as r_orders, count(*) as duplicate_count
 from orders
 join o_return on orders.order_id = o_return.order_id
 group by orders.order_id, o_return.order_id ) as derived_table;

-- substracting the above 2 we get result as 1920
-- CHECK FINAL
select count(*) from orders where order_id not in( select o_return.order_id from o_return);

 -- decending wise top revenue generating states.
 SELECT REGION, SUM(SALES) FROM ORDERS GROUP BY REGION ORDER BY SUM(SALES) DESC;
 
 -- most and least sales done in a month/ STATE/ REGION/ PRODUCTS/ SUB-PRODUCT WISE.
 -- MONTH WISE DIVISION
 SELECT MONTH(SALES) AS MONTHLY, SUM(SALES) AS TOTAL FROM ORDERS GROUP BY MONTHLY ORDER BY TOTAL DESC;
 
 -- most and least ordering customer with quantity and sales figure with profit
SELECT CUSTOMER_ID, CUSTOMER_NAME, SUM(QUANTITY_ORDERED_NEW) AS QUANTITY, SUM(SALES) AS T_SALES, SUM(PROFIT) AS T_PROFIT FROM ORDERS 
GROUP BY CUSTOMER_NAME, CUSTOMER_ID ORDER BY SUM(SALES) desc;

 -- period where the most orders where returned region wise
 SELECT ORDERS.ORDER_ID, O_RETURN.ORDER_ID, ORDERS.REGION, ORDERS.ORDER_DATE FROM ORDERS 
 NATURAL JOIN O_RETURN ORDER BY REGION AND ORDER_DATE ASC;
 
 -- order priority on the basis of region, state
 SELECT REGION, STATE_PROVINCE, COUNT(STATE_PROVINCE)
 FROM ORDERS WHERE ORDER_PRIORITY ='HIGH' GROUP BY STATE_PROVINCE, REGION;
 
 -- order priority on the basis of the customer_ID.
 SELECT CUSTOMER_ID, CUSTOMER_NAME, REGION, ORDER_PRIORITY, SUM(SALES), SUM(PROFIT) 
 FROM ORDERS GROUP BY CUSTOMER_NAME, CUSTOMER_ID, REGION, ORDER_PRIORITY ORDER BY ORDER_PRIORITY ASC;
 
 SELECT DISTINCT(ORDER_PRIORITY) FROM ORDERS;